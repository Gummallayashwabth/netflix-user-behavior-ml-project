# ==================================================
# RQ7 — CUSTOMER SEGMENTATION
# ==================================================

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os

from sklearn.cluster import KMeans
from sklearn.preprocessing import LabelEncoder

# ==================================================
# OUTPUT FOLDERS
# ==================================================

os.makedirs("/kaggle/working/outputs/figures", exist_ok=True)
os.makedirs("/kaggle/working/outputs/tables", exist_ok=True)

# ==================================================
# LOAD DATASET
# ==================================================

DATA_PATH = "/kaggle/input/datasets/rhythmghai/netflix-user-watching-behavior-dataset/netflix_user_behavior_dataset.csv"

df = pd.read_csv(DATA_PATH)

# ==================================================
# CLEAN DATA
# ==================================================

df = df.drop_duplicates()

# ==================================================
# ENCODE VARIABLES
# ==================================================

le = LabelEncoder()

for col in df.select_dtypes(include='object').columns:
    df[col] = le.fit_transform(df[col])

# ==================================================
# SELECT FEATURES
# ==================================================

features = df[[
    "avg_watch_time_minutes",
    "watch_sessions_per_week"
]]

# ==================================================
# APPLY KMEANS
# ==================================================

kmeans = KMeans(
    n_clusters=3,
    random_state=42
)

df["Cluster"] = kmeans.fit_predict(features)

# ==================================================
# CLUSTER SUMMARY
# ==================================================

cluster_summary = df.groupby("Cluster").mean()

print(cluster_summary)

# ==================================================
# SAVE TABLE
# ==================================================

cluster_summary.to_csv(
    "/kaggle/working/outputs/tables/rq7_cluster_summary.csv"
)

# ==================================================
# CREATE FIGURE
# ==================================================

plt.figure(figsize=(8,6))

sns.scatterplot(
    x="avg_watch_time_minutes",
    y="watch_sessions_per_week",
    hue="Cluster",
    data=df,
    palette="Set1"
)

plt.title("RQ7 Customer Segmentation")

plt.xlabel("Average Watch Time Minutes")
plt.ylabel("Watch Sessions Per Week")

plt.tight_layout()

# ==================================================
# SAVE FIGURE
# ==================================================

plt.savefig(
    "/kaggle/working/outputs/figures/rq7_cluster_plot.pdf",
    format="pdf"
)

plt.show()

print("RQ7 Completed Successfully")