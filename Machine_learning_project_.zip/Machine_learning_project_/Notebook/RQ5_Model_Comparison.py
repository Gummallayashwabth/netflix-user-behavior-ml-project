# ==================================================
# RQ5 — ROC CURVE COMPARISON
# ==================================================

import pandas as pd
import matplotlib.pyplot as plt
import os

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.metrics import roc_curve, auc

from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier

# ==================================================
# OUTPUT FOLDERS
# ==================================================

os.makedirs("/kaggle/working/outputs/figures", exist_ok=True)
os.makedirs("/kaggle/working/outputs/tables", exist_ok=True)

# ==================================================
# LOAD DATASET
# ==================================================

DATA_PATH = "/kaggle/input/datasets/rhythmghai/netflix-user-watching-behavior-dataset/netflix_user_behavior_dataset.csv"

df = pd.read_csv(DATA_PATH)

# ==================================================
# CLEAN DATA
# ==================================================

df = df.drop_duplicates()

# ==================================================
# ENCODE VARIABLES
# ==================================================

le = LabelEncoder()

for col in df.select_dtypes(include='object').columns:
    df[col] = le.fit_transform(df[col])

# ==================================================
# TARGET VARIABLE
# ==================================================

target = "churned"

X = df.drop(target, axis=1)
y = df[target]

# ==================================================
# SCALE FEATURES
# ==================================================

scaler = StandardScaler()

X = scaler.fit_transform(X)

# ==================================================
# SPLIT DATA
# ==================================================

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42
)

# ==================================================
# MODELS
# ==================================================

models = {
    "Logistic Regression": LogisticRegression(max_iter=5000),
    "Decision Tree": DecisionTreeClassifier(),
    "Random Forest": RandomForestClassifier()
}

roc_results = []

plt.figure(figsize=(8,6))

# ==================================================
# TRAIN MODELS
# ==================================================

for name, model in models.items():

    model.fit(X_train, y_train)

    y_prob = model.predict_proba(X_test)[:,1]

    fpr, tpr, _ = roc_curve(y_test, y_prob)

    roc_auc = auc(fpr, tpr)

    roc_results.append({
        "Model": name,
        "ROC_AUC": roc_auc
    })

    plt.plot(
        fpr,
        tpr,
        label=f"{name} AUC={roc_auc:.2f}"
    )

# RANDOM LINE
plt.plot([0,1],[0,1],'--')

plt.xlabel("False Positive Rate")
plt.ylabel("True Positive Rate")

plt.title("RQ5 ROC Curve Comparison")

plt.legend()

plt.tight_layout()

# ==================================================
# SAVE FIGURE
# ==================================================

plt.savefig(
    "/kaggle/working/outputs/figures/rq5_roc_curve.pdf",
    format="pdf"
)

plt.show()

# ==================================================
# SAVE TABLE
# ==================================================

roc_df = pd.DataFrame(roc_results)

print(roc_df)

roc_df.to_csv(
    "/kaggle/working/outputs/tables/rq5_roc_results.csv",
    index=False
)

print("RQ5 Completed Successfully")