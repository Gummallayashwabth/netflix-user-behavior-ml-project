# ==================================================
# RQ4 — ENGAGEMENT AND RETENTION ANALYSIS
# ==================================================

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os

from sklearn.preprocessing import LabelEncoder

# ==================================================
# OUTPUT FOLDERS
# ==================================================

os.makedirs("/kaggle/working/outputs/figures", exist_ok=True)
os.makedirs("/kaggle/working/outputs/tables", exist_ok=True)

# ==================================================
# LOAD DATASET
# ==================================================

DATA_PATH = "/kaggle/input/datasets/rhythmghai/netflix-user-watching-behavior-dataset/netflix_user_behavior_dataset.csv"

df = pd.read_csv(DATA_PATH)

# ==================================================
# CLEAN DATA
# ==================================================

df = df.drop_duplicates()

# ==================================================
# ENCODE CATEGORICAL VARIABLES
# ==================================================

le = LabelEncoder()

for col in df.select_dtypes(include='object').columns:
    df[col] = le.fit_transform(df[col])

# ==================================================
# SELECT VARIABLES
# ==================================================

engagement_col = "content_interactions"
retention_col = "churned"

# ==================================================
# CREATE ANALYSIS TABLE
# ==================================================

retention_df = df[[engagement_col, retention_col]]

print(retention_df.head())

# ==================================================
# SAVE TABLE
# ==================================================

retention_df.to_csv(
    "/kaggle/working/outputs/tables/rq4_retention_analysis.csv",
    index=False
)

# ==================================================
# CREATE FIGURE
# ==================================================

plt.figure(figsize=(8,5))

sns.scatterplot(
    data=retention_df,
    x=engagement_col,
    y=retention_col
)

plt.title("RQ4 Engagement vs Retention")

plt.xlabel("Content Interactions")
plt.ylabel("Churned")

plt.tight_layout()

# ==================================================
# SAVE FIGURE
# ==================================================

plt.savefig(
    "/kaggle/working/outputs/figures/rq4_retention_scatter.pdf",
    format="pdf"
)

plt.show()

print("RQ4 Completed Successfully")