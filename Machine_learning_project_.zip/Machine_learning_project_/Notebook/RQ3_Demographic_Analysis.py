# ==================================================
# RQ3 — CUSTOMER DEMOGRAPHIC ANALYSIS
# ==================================================

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os

# ==================================================
# CREATE OUTPUT FOLDERS
# ==================================================

os.makedirs("/kaggle/working/outputs/figures", exist_ok=True)
os.makedirs("/kaggle/working/outputs/tables", exist_ok=True)

# ==================================================
# LOAD DATASET
# ==================================================

DATA_PATH = "/kaggle/input/datasets/rhythmghai/netflix-user-watching-behavior-dataset/netflix_user_behavior_dataset.csv"

df = pd.read_csv(DATA_PATH)

print(df.head())

# ==================================================
# SELECT COLUMNS
# ==================================================

age_col = "age"

watch_col = "avg_watch_time_minutes"

# ==================================================
# CREATE AGE GROUPS
# ==================================================

df["Age_Group"] = pd.cut(
    df[age_col],
    bins=[0,18,25,35,45,55,100],
    labels=["<18","18-25","26-35","36-45","46-55","55+"]
)

# ==================================================
# GROUP ANALYSIS
# ==================================================

age_analysis = df.groupby(
    "Age_Group",
    observed=False
)[watch_col].mean().reset_index()

print(age_analysis)

# ==================================================
# SAVE TABLE
# ==================================================

age_analysis.to_csv(
    "/kaggle/working/outputs/tables/rq3_age_analysis.csv",
    index=False
)

# ==================================================
# GENERATE FIGURE
# ==================================================

plt.figure(figsize=(8,5))

sns.lineplot(
    data=age_analysis,
    x="Age_Group",
    y=watch_col,
    marker="o"
)

plt.title("RQ3 Average Watch Time by Age Group")

plt.xlabel("Age Group")

plt.ylabel("Average Watch Time (Minutes)")

plt.tight_layout()

# ==================================================
# SAVE FIGURE
# ==================================================

plt.savefig(
    "/kaggle/working/outputs/figures/rq3_age_group_analysis.pdf",
    format="pdf"
)

plt.show()

print("RQ3 Completed Successfully")