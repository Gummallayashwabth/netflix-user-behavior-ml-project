# ==================================================
# RQ2 — FEATURE IMPORTANCE ANALYSIS
# ==================================================

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os

from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder

os.makedirs("/kaggle/working/outputs/figures", exist_ok=True)
os.makedirs("/kaggle/working/outputs/tables", exist_ok=True)

DATA_PATH = "/kaggle/input/datasets/rhythmghai/netflix-user-watching-behavior-dataset/netflix_user_behavior_dataset.csv"

df = pd.read_csv(DATA_PATH)

# CLEAN
df = df.drop_duplicates()

# ENCODE
le = LabelEncoder()

for col in df.select_dtypes(include='object').columns:
    df[col] = le.fit_transform(df[col])

# TARGET
target = "churned"

X = df.drop(target, axis=1)
y = df[target]

# MODEL
model = RandomForestClassifier(random_state=42)

model.fit(X, y)

# IMPORTANCE
importance_df = pd.DataFrame({
    "Feature": X.columns,
    "Importance": model.feature_importances_
})

importance_df = importance_df.sort_values(
    by="Importance",
    ascending=False
)

print(importance_df)

# SAVE TABLE
importance_df.to_csv(
    "/kaggle/working/outputs/tables/rq2_feature_importance.csv",
    index=False
)

# FIGURE
plt.figure(figsize=(10,6))

sns.barplot(
    data=importance_df.head(10),
    x="Importance",
    y="Feature"
)

plt.title("RQ2 Feature Importance")

plt.tight_layout()

plt.savefig(
    "/kaggle/working/outputs/figures/rq2_feature_importance.pdf",
    format='pdf'
)

plt.show()

print("RQ2 Completed Successfully")