# ==================================================
# RQ6 — CORRELATION ANALYSIS
# ==================================================

import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import os

from sklearn.preprocessing import LabelEncoder

# ==================================================
# OUTPUT FOLDERS
# ==================================================

os.makedirs("/kaggle/working/outputs/figures", exist_ok=True)
os.makedirs("/kaggle/working/outputs/tables", exist_ok=True)

# ==================================================
# LOAD DATASET
# ==================================================

DATA_PATH = "/kaggle/input/datasets/rhythmghai/netflix-user-watching-behavior-dataset/netflix_user_behavior_dataset.csv"

df = pd.read_csv(DATA_PATH)

# ==================================================
# CLEAN DATA
# ==================================================

df = df.drop_duplicates()

# ==================================================
# ENCODE VARIABLES
# ==================================================

le = LabelEncoder()

for col in df.select_dtypes(include='object').columns:
    df[col] = le.fit_transform(df[col])

# ==================================================
# CORRELATION MATRIX
# ==================================================

corr_matrix = df.corr()

print(corr_matrix)

# ==================================================
# SAVE TABLE
# ==================================================

corr_matrix.to_csv(
    "/kaggle/working/outputs/tables/rq6_correlation_matrix.csv"
)

# ==================================================
# HEATMAP
# ==================================================

plt.figure(figsize=(14,10))

sns.heatmap(
    corr_matrix,
    annot=True,
    cmap="coolwarm"
)

plt.title("RQ6 Correlation Heatmap")

plt.tight_layout()

# ==================================================
# SAVE FIGURE
# ==================================================

plt.savefig(
    "/kaggle/working/outputs/figures/rq6_heatmap.pdf",
    format="pdf"
)

plt.show()

print("RQ6 Completed Successfully")